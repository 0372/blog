<?php
//用于配置自定义的css和js文件路径
$config['backend_css'] = array(
    'application/views/pulic/css/bootstrap.css',
    'application/views/pulic/css/bootstrap-theme.css',
    'application/views/pulic/css/bootstrap-theme.min.css'
);

$config['backend_js'] = array(
    'application/views/public/js/bootstrap.js',
    'application/views/public/js/bootstrap.min.js',
    'application/views/public/js/npm.js'
);