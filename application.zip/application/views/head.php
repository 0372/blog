<?php echo $head?>
this is a head file;
